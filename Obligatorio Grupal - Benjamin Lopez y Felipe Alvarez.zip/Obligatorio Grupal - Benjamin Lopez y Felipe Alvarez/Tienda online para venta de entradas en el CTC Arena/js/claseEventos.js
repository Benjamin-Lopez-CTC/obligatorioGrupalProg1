export class Evento {
    constructor(imagen, codigo, tipo, artista, categoria, fecha, precio, cantidadVendida) {
        this.imagen = imagen;
        this.codigo = codigo;
        this.tipo = tipo;
        this.artista = artista;
        this.categoria = categoria;
        this.fecha = fecha;
        this.precio = precio;
        this.cantidadVendida = cantidadVendida;
    }
}